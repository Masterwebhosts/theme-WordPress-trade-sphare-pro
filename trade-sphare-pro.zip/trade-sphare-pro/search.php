<?php
/**
 * Trade Sphare Pro - Search Results
 *
 * @package TradeSpharePro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="ts-site-main">

	<div class="ts-container">

		<div class="ts-content-area">

			<header class="ts-post-header">

				<h1 class="ts-post-title">

					<?php
					printf(
						esc_html__( 'Search Results for: %s', 'trade-sphare-pro' ),
						'<span>' . esc_html( get_search_query() ) . '</span>'
					);
					?>

				</h1>

			</header>

			<?php if ( have_posts() ) : ?>

				<div class="ts-archive-grid">

					<?php while ( have_posts() ) : the_post(); ?>

						<article
							id="post-<?php the_ID(); ?>"
							<?php post_class( 'ts-post-card' ); ?>
						>

							<?php if ( has_post_thumbnail() ) : ?>

								<a
									class="ts-post-thumbnail"
									href="<?php the_permalink(); ?>"
									aria-label="<?php echo esc_attr( get_the_title() ); ?>"
								>

									<?php
									the_post_thumbnail(
										'trade-sphare-pro-card',
										array(
											'loading' => 'lazy',
										)
									);
									?>

								</a>

							<?php endif; ?>

							<header class="ts-post-header">

								<div class="ts-post-meta">

									<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
										<?php echo esc_html( get_the_date() ); ?>
									</time>

									<?php if ( get_the_author() ) : ?>

										<span>
											<?php
											printf(
												esc_html__( ' — By %s', 'trade-sphare-pro' ),
												esc_html( get_the_author() )
											);
											?>
										</span>

									<?php endif; ?>

								</div>

								<h2 class="ts-post-title">

									<a href="<?php the_permalink(); ?>">
										<?php the_title(); ?>
									</a>

								</h2>

							</header>

							<div class="ts-post-content">

								<?php
								echo esc_html(
									wp_trim_words(
										get_the_excerpt(),
										22
									)
								);
								?>

							</div>

							<a
								class="ts-text-link"
								href="<?php the_permalink(); ?>"
								aria-label="<?php echo esc_attr( 'Read: ' . get_the_title() ); ?>"
							>
								<?php esc_html_e( 'Read Article →', 'trade-sphare-pro' ); ?>
							</a>

						</article>

					<?php endwhile; ?>

				</div>

				<?php
				the_posts_pagination(
					array(
						'mid_size'  => 2,
						'prev_text' => __( '← Previous', 'trade-sphare-pro' ),
						'next_text' => __( 'Next →', 'trade-sphare-pro' ),
						'class'     => 'ts-pagination',
					)
				);
				?>

			<?php else : ?>

				<section class="ts-no-results">

					<h1>
						<?php esc_html_e( 'No Results Found', 'trade-sphare-pro' ); ?>
					</h1>

					<p>
						<?php
						esc_html_e(
							'Try searching with different keywords.',
							'trade-sphare-pro'
						);
						?>
					</p>

					<?php get_search_form(); ?>

				</section>

			<?php endif; ?>

		</div>

	</div>

</main>

<?php
get_footer();
?>